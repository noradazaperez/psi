link
    <link rel="stylesheet" href=¡link a donde se encuentra el css, si es un archivo poner entre comillas!>
    (*) <link rel="stylesheet" href="styles.css">
    Te permite añadir css desde un archivo externo
    En 