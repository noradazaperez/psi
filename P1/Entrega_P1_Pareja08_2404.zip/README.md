Link donde esta desplegada la práctica:
    https://p1-08-2404-2026-1.onrender.com

La versión local del servidor también se conecta a la base de datos de Neon.tech.
Esto es para facilitar añadir superusuarios y modificar la información de la aplicación desplegada.